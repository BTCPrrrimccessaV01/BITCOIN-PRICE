@echo off
setlocal
set "URL=https://TWOJA-NAZWA.github.io/darmowa-prognoza-btc/"
if exist "%~dp0adres.txt" set /p URL=<"%~dp0adres.txt"
set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if exist "%EDGE%" (start "" "%EDGE%" --app="%URL%" & exit /b)
if exist "%CHROME%" (start "" "%CHROME%" --app="%URL%" & exit /b)
start "" "%URL%"
